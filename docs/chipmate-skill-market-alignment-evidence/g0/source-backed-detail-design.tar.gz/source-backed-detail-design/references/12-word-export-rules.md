# 12 Word Export Rules

## 1. Kilo Word route

When the user asks for Word output, generate the `.docx` with Kilo's generic Word tool: `create_word_document`. Do not introduce a task-specific Word pipeline, local pandoc, local LibreOffice/soffice export, or a standalone node-docx script as the primary or fallback route. `08-word-export-input.md`, when used, is an auditable assembly draft, not the final export mechanism.

## 2. create_word_document arguments

Before calling `create_word_document`, build object-shaped top-level arguments with `title`, optional document fields, and `sections`. Never wrap the arguments in another object or pass stringified JSON, quoted JSON, Markdown, or prose. Use assumptions, limitations, gaps, and owner-review items for incomplete evidence rather than continuing unbounded search.

Sections should preserve the enhanced design structure: overview, business flow overview, architecture/dependencies, core data structures, interface design, main flow, state machine and exceptions, submodule business flows, code-level submodule flows, resources/performance, build/integration, source evidence appendix, diff report, and quality gates.

## 3. Figures and diagrams

Track `diagramId -> targetSection -> pngPath -> QA status`. Insert every successfully rendered Mermaid diagram as an image block in the exact `sections[].blocks[]` position where it is explained:

```json
{
  "type": "image",
  "path": "<pngPath returned by render_mermaid_diagram>",
  "contentType": "image/png",
  "title": "Figure title",
  "caption": "Figure explanation",
  "altText": "Accessible description",
  "width": 480,
  "height": 280
}
```

Use ordered blocks to control surrounding text, image, title, and caption placement. Use the render result's display width and height when suitable and retain pixel dimensions as QA evidence. Keep `.mmd` paths in diagram indexes and evidence ledgers for traceability. If the user explicitly asks for Mermaid source in Word, use a normal code block with Mermaid source; otherwise rendered diagrams must be PNG images.

## 4. Render verification

After `create_word_document` succeeds, call `inspect_word_document` and require `imageCount` to match the number of successful renders planned for insertion. If it does not match, reuse the existing PNG for each missing figure with `insert_mermaid_into_word`, then inspect again. Do not regenerate unrelated document content.

For the full detailed-design Word workflow, call `render_word_document` after the image-count check. The configured Render Service performs page rendering and visual QA. If remote render is unconfigured or unavailable, continue the Word delivery and disclose that page-level visual QA was skipped. If render returns page PNGs or visual summaries with material risks, report them and fix through the generic Word tools only within the requested document scope.

## 5. Success criteria

A completed Word deliverable should report the non-empty `.docx` path returned by `create_word_document`, Mermaid render and QA status, successful planned figure count, inspected image count, any bounded repair, and whether final Word render QA ran, skipped, or failed. A Markdown draft, Mermaid source, or `08-word-export-input.md` alone is not a Word deliverable unless the user explicitly asked only for a draft.
